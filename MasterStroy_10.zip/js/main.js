import Header from "./Header.js";

new Header();
